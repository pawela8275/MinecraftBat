switch (key) {
    case value:
        
        break;

    default:
        break;
}
end